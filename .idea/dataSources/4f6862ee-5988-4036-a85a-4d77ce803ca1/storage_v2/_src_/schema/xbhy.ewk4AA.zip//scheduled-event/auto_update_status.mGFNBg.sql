create definer = root@localhost event auto_update_status on schedule
  every '1' SECOND
    starts '2019-12-13 12:36:21'
  enable
  do
  begin
	-- 修改使用子查询,否则报错(You can't specify target table 'meeting' for update in FROM clause) 不可以在update语句中使用本表查询
	update meeting set status = 1 where id in (
	
		select a.id from (
			select id from meeting where DATE_FORMAT(start_time,'%Y-%m-%d %H:%i')=DATE_FORMAT(now(),'%Y-%m-%d %H:%i')
		
		) a
	
	);
	update meeting set status = 2 where id in (
	
		select a.id from (
			select id from meeting where DATE_FORMAT(end_time,'%Y-%m-%d %H:%i')=DATE_FORMAT(now(),'%Y-%m-%d %H:%i')
		) a
	
	);
end;

